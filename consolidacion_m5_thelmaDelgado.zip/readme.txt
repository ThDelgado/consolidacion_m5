CUE: FUNDAMENTOS DE BASES DE DATOS RELACIONALES 
FINAL DRILLING: ARRIENDO DE DVDS 

consolidacion 
m5

para clonar:
https://github.com/ThDelgado/consolidacion_m5.git

Thelma Delgado